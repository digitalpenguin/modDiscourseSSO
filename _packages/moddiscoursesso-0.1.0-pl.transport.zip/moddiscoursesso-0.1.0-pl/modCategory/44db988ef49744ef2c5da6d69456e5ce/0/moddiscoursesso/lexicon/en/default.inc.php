<?php
/**
 * Default English Lexicon Entries for modDiscourseSSO
 *
 * @package moddiscoursesso
 * @subpackage lexicon
 */

$_lang['moddiscoursesso'] = 'modDiscourseSSO';

